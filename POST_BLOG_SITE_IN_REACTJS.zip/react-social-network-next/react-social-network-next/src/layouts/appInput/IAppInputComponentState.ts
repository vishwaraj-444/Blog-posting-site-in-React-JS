export interface IAppInputComponentState {

}
