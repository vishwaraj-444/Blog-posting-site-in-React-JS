export interface IAppInputComponentProps {

}
