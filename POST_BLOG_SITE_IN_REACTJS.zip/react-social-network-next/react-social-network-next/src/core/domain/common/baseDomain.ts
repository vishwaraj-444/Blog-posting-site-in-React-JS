
export class BaseDomain {
   
}