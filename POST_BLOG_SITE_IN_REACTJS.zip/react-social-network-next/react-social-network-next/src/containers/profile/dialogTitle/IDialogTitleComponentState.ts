export interface IDialogTitleComponentState {

}
