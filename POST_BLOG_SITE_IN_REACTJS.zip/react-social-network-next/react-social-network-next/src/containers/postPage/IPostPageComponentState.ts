
export interface IPostPageComponentState {

}
