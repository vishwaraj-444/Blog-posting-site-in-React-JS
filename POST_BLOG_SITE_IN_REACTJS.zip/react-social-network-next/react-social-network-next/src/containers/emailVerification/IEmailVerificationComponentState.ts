
export interface IEmailVerificationComponentState {

}
