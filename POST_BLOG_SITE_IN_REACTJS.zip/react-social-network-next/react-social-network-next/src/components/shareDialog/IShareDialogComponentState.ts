
export interface IShareDialogComponentState {

}
