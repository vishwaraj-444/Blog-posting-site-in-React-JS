
export interface IMasterLoadingComponentState {

}
