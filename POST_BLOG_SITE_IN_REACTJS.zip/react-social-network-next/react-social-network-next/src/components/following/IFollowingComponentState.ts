
export interface IFollowingComponentState {

}
