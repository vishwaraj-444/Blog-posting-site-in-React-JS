
export interface IImageGalleryComponentState {

}
