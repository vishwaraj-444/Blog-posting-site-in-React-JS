
export interface IUserAvatarComponentState {

}
