
export interface ISidebarMainComponentState {

}
