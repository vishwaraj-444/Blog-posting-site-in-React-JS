
export interface IFindPeopleComponentState {

}
