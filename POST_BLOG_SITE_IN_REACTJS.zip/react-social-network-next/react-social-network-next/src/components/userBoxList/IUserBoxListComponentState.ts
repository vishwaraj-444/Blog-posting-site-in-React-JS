
export interface IUserBoxListComponentState {

}
