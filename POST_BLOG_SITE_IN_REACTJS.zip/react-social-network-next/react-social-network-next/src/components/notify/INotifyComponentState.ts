
export interface INotifyComponentState {

}
