
export interface ISidebarContentComponentState {

}
