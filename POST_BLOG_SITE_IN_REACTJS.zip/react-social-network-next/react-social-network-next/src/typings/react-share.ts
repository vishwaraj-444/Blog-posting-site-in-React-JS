declare module 'react-share'
