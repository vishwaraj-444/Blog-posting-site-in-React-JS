declare module 'react-parallax'
