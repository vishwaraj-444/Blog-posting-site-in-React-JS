
   ```
1. Go to the project root directory 
   ```bash
   cd react-social-network
   ```
1. To install node dependencies use 
  ```bash
  npm install

    npm start
    ```

